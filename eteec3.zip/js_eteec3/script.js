const box = document.querySelector('.contain')
var color = ['red','blue', 'green','yellow']
var count = 0
function changecolor(){
    if(count >= color.length){
        count = 0
    }
    box.computedStyleMap.background = color[count]
    count ++
}
setInterval(changecolor, 3000)